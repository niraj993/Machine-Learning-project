# -*- coding: utf-8 -*-
"""
Created on Tue May 24 16:37:32 2022

@author: Dayanand
"""


# loading library

import pandas as pd
import numpy as np
import os
import seaborn as sns
import matplotlib.pyplot as plt

# To view all rows and columns while displaying a df

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

# changing the directory

os.chdir("C:\\Users\\Dayanand\\Desktop\\DataScience\\Imarticus hackathon\\Project\\ECommerce")

# loading file

fullDf=pd.read_excel("E-com_Data.xlsx")

# let us seee the dta

fullDf.head().T

# Dimension of data

fullDf.shape

# Columns and info

fullDf.columns

# info of the columns

fullDf.info()

# Let us check missing values

fullDf.isna().sum()

# Copy the file

rawDf=fullDf.copy()

# Let us keep the column names properly

rawDf.columns=["CustomerID","ItemCode","InvoiceNo","Date_Of_Purchase","Quantity",
               "Time_Of_Purchase","PricePerUnit","TotalSales","ShippingLocation","Cancelled_Status",
              "Reason_Of_Return","SoldAsSet"]

# Letus drop SoldAsSet columns since it contains all missing values
 
rawDf.drop(["SoldAsSet"],axis=1,inplace=True)


# let us drop nan rows from CustomerID

rawDf.dropna(axis=0,subset=["CustomerID"],inplace=True)

rawDf.isna().sum()

# Let us impute missing values for Cancelled_Status


rawDf["Cancelled_Status"]=np.where(rawDf.TotalSales<0,"True","False")


# imputing Reson_Of_Return

rawDf["Reason_Of_Return"]=np.where(rawDf.TotalSales>0,"Satisfied","Not Satisfied")

# let us reconfim for miising values

rawDf.isna().sum()

# Let us do EDA to understand data

# Let us analyse Location column

productDf=rawDf[["ShippingLocation","CustomerID"]]
productDf.groupby("ShippingLocation").sum().plot(kind="bar")

# Obs.- Highest no of customers have order at Location 36

productDf1=rawDf[["ShippingLocation","Price"]]
productDf2=rawDf[["ShippingLocation","Quantity"]]
productDf1.groupby("ShippingLocation").sum().plot(kind="bar")
productDf2.groupby("ShippingLocation").sum().plot(kind="bar")

# loading library

import dateutil
import datetime as dt

#convert time from object datatype to date times

rawDf['InvoiceDate']=rawDf.apply(lambda r : pd.datetime.combine(r['Date_Of_Purchase'],r['Time_Of_Purchase']),1)
rawDf['InvoiceDate'].head()
#Extract month and year together from column in pandas:
rawDf['year_month']=pd.to_datetime(rawDf['Date_Of_Purchase']).dt.to_period('M')

#Extract month,year,day and hour separetly from column 'InvoiceNo'

rawDf['year']=rawDf['Date_Of_Purchase'].dt.year
rawDf['month']=rawDf['Date_Of_Purchase'].dt.month
rawDf['day']=rawDf['Date_Of_Purchase'].dt.day
rawDf['hour']=rawDf['Date_Of_Purchase'].dt.hour

# Tracking of Sales Month wise
ax_rev=rawDf.groupby('year_month')['Price'].sum().sort_index().plot(kind='line',figsize=(20,6))
ax_rev.set_xlabel('Month Year',fontsize=15)
ax_rev.set_ylabel('Sales',fontsize=15)
ax_rev.set_title('Sales for different Months (DEC 2016 - DEC 2017)',fontsize=10)
plt.show()
 
# Products ,Customers & Sales Analysis year by year
df1=pd.DataFrame({'products': rawDf['ItemCode'].nunique(),    
               'transactions': rawDf['InvoiceNo'].nunique(),
               'customers': rawDf['CustomerID'].nunique(),  
              }, index = ['quantity_2016'])

df2=pd.DataFrame({'products': rawDf['ItemCode'].nunique(),    
               'transactions': rawDf['InvoiceNo'].nunique(),
               'customers': rawDf['CustomerID'].nunique()}, index =['quantity_2017'])
    

    
frames = [df1, df2]
result = pd.concat(frames)        

print('\nTotal number of products, transactions and customers by years')
pd.DataFrame(result)

# Top 10 products sold by Quantity
rawDf.iloc[:10].plot.line(x = 'ItemCode', y = 'Quantity', 
                                 color = 'skyblue', 
                                 title = 'Top 10 Sold Products By Quantity')


############
### RFM
############

# Let us calcuate R,F,M values

# Reference Date=2016-12-02

reference_date=rawDf.Date_Of_Purchase.max()
reference_date


#recency

rawDf_recency=rawDf.copy()
rawDf_recency=rawDf_recency.groupby(by="CustomerID",as_index=False)["Date_Of_Purchase"].max()
rawDf_recency.columns=["CustomerID","max_date"]
rawDf_recency

rawDf_recency["Recency"]=rawDf_recency["max_date"].apply(lambda row:(reference_date-row).days)
rawDf_recency.drop("max_date",inplace=True,axis=1)

rawDf_recency.head()

# Recency Plot
plt.figure(figsize=(20,20))
sns.distplot(rawDf_recency)

# Frequency
rawDf_frequency=rawDf.copy()
rawDf_frequency=rawDf_frequency.groupby(by="CustomerID",as_index=False)["InvoiceNo"].nunique()
rawDf_frequency.columns=["CustomerID","Frequency"]
rawDf_frequency.head()

# Frequency Plot
plt.figure(figsize=(20,20))
sns.distplot(rawDf_frequency)

# Monetary
rawDf_monetary=rawDf.copy()
rawDf_monetary=rawDf_monetary.groupby(by="CustomerID",as_index=False)["TotalSales"].sum()
rawDf_monetary.columns=["CustomerID","Monetary"]
rawDf_monetary.tail()

# Moneatary Plot
plt.figure(figsize=(20,20))
sns.distplot(rawDf_monetary.Monetary)
 
# Let us merge all three data frames and create a new data frame

rfm=pd.concat([rawDf_recency,rawDf_frequency.Frequency,rawDf_monetary.Monetary],axis=1)

# Let us analyse using scatter plot

# Recency VS Frequency

plt.scatter(rfm.groupby("CustomerID")["Recency"].sum(),rawDf.groupby("CustomerID")
           ["Quantity"].sum(),color="red")
plt.title("Recency VS Frequency")
plt.xlabel("Recency")
plt.ylabel("Frequency")

# Frequency Vs Monetary
market_data=rawDf.groupby("CustomerID")[["Quantity","Price"]].sum()
plt.scatter(market_data["Price"],market_data["Quantity"],color="red")
plt.title("Frequency VS Monetary")
plt.xlabel("Frequency")
plt.ylabel("Monetary")

# Recency Vs Frequency VS Monetory
Monetary=rawDf.groupby("CustomerID")["Price"].sum()
plt.scatter(rfm.groupby("CustomerID")["Recency"].sum(),
           rawDf.groupby("CustomerID")["Quantity"].sum(),
           marker="*",alpha=0.3,c=Monetary)
plt.title("Receny VS Frequency VS Monetary")
plt.xlabel("Receny")
plt.ylabel("Frequency")

# Standardization of data sets

rfmDf=rfm.drop(["CustomerID"],axis=1).copy()

from sklearn.preprocessing import StandardScaler


rfmScaling=StandardScaler().fit(rfmDf)
rfmStd=rfmScaling.transform(rfmDf)

rfmStd=pd.DataFrame(rfmStd,columns=rfmDf.columns)
rfmStd.head()
rfmStd.index=rfm["CustomerID"]
rfmStd.head()
rfmStd.shape

# Number of clusters -elbow method
from sklearn.cluster import KMeans 
wss=[]
for k in range(1,10):
    kmeans=KMeans(n_clusters=k,random_state=2410).fit(rfmStd)
    wss.append(kmeans.inertia_)

print(wss)


# plotting a line graph
sns.lineplot(x=range(1,10),y=wss)

# Modeling
# clustering with kmeans=4

KMeans_Model=KMeans(n_clusters=4,random_state=2410).fit(rfmStd)


# Silhoutter value 

from sklearn.metrics import silhouette_samples, silhouette_score
rfmStd['Silhouette_value']=silhouette_samples(rfmStd,KMeans_Model.labels_)
rfmStd.head()

#overall silhouette score

silhouette_score(rfmStd,KMeans_Model.labels_) # 0.60

# Cluster info with rfm dataframe

rfm["Silhouette_value"]=rfmStd["Silhouette_value"]
rfm.head()

clusterDf=pd.concat([rfm,pd.Series(KMeans_Model.labels_)],axis=1).rename(columns={0:"cluster"})

clusterDf.head(10)


# Cluster Profiling

cluster_profileDf=clusterDf.groupby("cluster").mean().reset_index()
cluster_profileDf.head()

#cluster-wise silhouette scores

cluster_profileDf.groupby(['cluster'])['Silhouette_value'].mean()

# Ranking the cluster based on RFM value
cluster_profileDf['R_rank'] = cluster_profileDf["Recency"].rank(ascending=False)
cluster_profileDf['F_rank'] = cluster_profileDf['Frequency'].rank(ascending=True)
cluster_profileDf['M_rank'] = cluster_profileDf['Monetary'].rank(ascending=True)
cluster_profileDf

cluster_profileDf["RFMScore"]=cluster_profileDf['R_rank']+cluster_profileDf['F_rank']+cluster_profileDf['M_rank']

cluster_profileDf.head()

# Naming the clustering based on RFM values

cluster_profileDf.rename({0:"LowValueCustomer",
                          1:"HighValueCustomer",
                          2:"MediumValueCustomer",
                          3:"LostCustomer"},inplace=True)

cluster_profileDf.head

# cluster Percentage 

((cluster_profileDf["CustomerID"].value_counts()/cluster_profileDf.shape[0])*100)


# Clustering Analysis using scatter graph

sns.scatterplot(x = 'Frequency', y = 'Monetary',  data = cluster_profileDf, hue = "cluster", palette = ["red", "green", "blue","yellow"])

sns.scatterplot(x = 'Monetary', y = 'Recency',  data = cluster_profileDf, hue = "cluster", palette = ["red", "green", "blue","yellow"])

sns.scatterplot(x = 'Recency', y = 'Frequency',  data = cluster_profileDf, hue = "cluster", palette = ["red", "green", "blue","yellow"])

# Melt the data into along format so RFM values and metric names are stored in 1 column each

data_melt = pd.melt(cluster_profileDf.reset_index(),
                    id_vars=["CustomerID",'cluster'],
                    value_vars=['Recency', 'Frequency', 'Monetary'],
                    var_name='Attribute',
                    value_name='Value')


plt.title('Snake plot of standardized variables')

sns.lineplot(x="Attribute", y="Value", hue='cluster', data=data_melt)

